//
//  NotificationViewController.swift
//  ContentExtension
//
//  Created by Bhavesh Sarwar on 20/06/22.
//

import UIKit
import UserNotifications
import UserNotificationsUI
import WebEngageAppEx

class NotificationViewController: WEXRichPushNotificationViewController {
}
